# MongoDB Queries and Outputs

This repository contains MongoDB queries and their respective outputs, submitted by **Chandru.V** as part of a practical task.

## Contents

- `queries-7.pdf` — A PDF document that includes MongoDB queries such as:
  - Inserting single/multiple documents
  - Querying documents with conditions
  - Using logical operators
  - Finding documents with specific field values

## Author

Chandru.V